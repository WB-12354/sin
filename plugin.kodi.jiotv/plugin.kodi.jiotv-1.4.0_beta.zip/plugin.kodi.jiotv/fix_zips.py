import zipfile
import os

def fix_zip(zip_path):
    if not os.path.exists(zip_path):
        return
    print(f"Fixing {zip_path}")
    temp_zip = zip_path + ".tmp"
    with zipfile.ZipFile(zip_path, 'r') as zin, zipfile.ZipFile(temp_zip, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            content = zin.read(item.filename)
            new_name = item.filename.replace('\\', '/')
            zout.writestr(new_name, content)
    os.remove(zip_path)
    os.rename(temp_zip, zip_path)

fix_zip("repository.jiotvdirect-1.0.0.zip")
fix_zip("plugin.kodi.jiotv-1.4.0_beta.zip")
